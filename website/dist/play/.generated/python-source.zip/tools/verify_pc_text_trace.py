#!/usr/bin/env python3
"""Check bounded presentation capture parity and crop saved source frames."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from PIL import Image


def verify(trace_path, baseline_path):
    trace=json.loads(trace_path.read_text());baseline=json.loads(baseline_path.read_text())
    rows=trace['presentations'];runs=[run for row in rows for run in row.get('text_runs',[])]
    counts=Counter((run['kind'],run['text']) for run in runs)
    stats=trace['text_observation']
    checks={
        'same_profile_and_start':trace['profile']==baseline['profile'] and
            trace['state_sha256']==baseline['state_sha256'] and
            trace['state_core_sha256']==baseline['state_core_sha256'],
        'full_RAM_video_inputs_identical':trace['frames']==baseline['frames'] and len(trace['frames'])>1000,
        'all_stage_states_identical':trace['stages']==baseline['stages'],
        'all_native_text_returns_match_source_glyphs':stats.get('entries',0)>0 and
            stats.get('entries')==stats.get('glyph_verified'),
        'no_unsupported_or_bad_glyph_entries':not any(stats.get(k,0) for k in
            ('unsupported_entries','unsupported_returns','glyph_mismatches')),
        'presented_evidence_accounted':len(runs)==stats.get('presented_runs'),
        'visibility_gate_exercised':stats.get('frame_mismatches',0)>0,
        'every_run_belongs_to_scanned_page':all(run['page_offset']==row['page_offset'] for row in rows for run in row.get('text_runs',[])),
    }
    readiness_delays=[]
    if trace['profile']=='audio':
        checks['three_original_weapon_labels_visible']=all(counts[('weapon_status',text)]>0 for text in ('READY ','TRACK ','LOAD  '))
        for event in trace['audio_events']:
            if event['kind']!='reload_complete': continue
            frame=event['frame_index']
            first=next((i for i in range(frame,len(rows)) if any(run['kind']=='weapon_status' and
                run['text']=='READY ' for run in rows[i].get('text_runs',[]))),None)
            readiness_delays.append({'completion_frame':frame,'first_visible_ready':first,
                                     'delay_frames':None if first is None else first-frame})
        checks['observed_reload_is_earlier_than_visible_readiness']=len(readiness_delays)==3 and all(
            item['delay_frames'] is not None and item['delay_frames']>0 for item in readiness_delays)
    if trace['profile']=='text':
        checks['original_empty_smoke_message_visible']=counts[('crew_primary','No smoke mortars left')]>0
        expiry=next(item for item in trace['ui_presentations'] if item['stage']=='crew-expired')
        checks['erased_message_not_exposed']=not any(run['kind'].startswith('crew_') for run in rows[expiry['frame_index']].get('text_runs',[]))
    captures=[]
    for sample in trace['ui_presentations']:
        source=trace_path.parent/sample['image']
        with Image.open(source) as image:
            image=image.convert('RGB')
            for run in rows[sample['frame_index']].get('text_runs',[]):
                x,y,w,h=run['rect'];actual=hashlib.sha256(image.crop((x,y,x+w,y+h)).tobytes()).hexdigest()
                captures.append({'image':sample['image'],'kind':run['kind'],'text':run['text'],
                                 'sha256':actual,'matches':actual==run['pixel_sha256']})
    checks['saved_source_crops_match_runtime_evidence']=all(c['matches'] for c in captures)
    if trace['profile']=='text': checks['saved_crew_crop_exercised']=any(c['kind']=='crew_primary' for c in captures)
    orientation_crops=[]
    if trace['profile']=='orientation':
        observation=trace['orientation_observation']
        packets=[row['orientation'] for row in rows if row.get('orientation')]
        checks['all_orientation_entries_completed']=observation.get('entries',0)>0 and observation['entries']==observation.get('completed_draws')
        checks['no_orientation_rejections']=set(observation)<=set(('entries','completed_draws','presented_draws','frame_mismatches'))
        checks['orientation_presented_count']=len(packets)==observation.get('presented_draws')
        checks['orientation_visibility_gate_exercised']=observation.get('frame_mismatches',0)>0
        checks['orientation_same_page']=all(row['orientation']['page_offset']==row['page_offset'] for row in rows if row.get('orientation'))
        stages={}
        for entry in trace['ui_presentations']:
            item=rows[entry['frame_index']].get('orientation',{})
            if not item: continue
            stages[entry['stage']]=item
            x,y,w,h=item['rect']
            with Image.open(trace_path.parent/entry['image']) as image:
                digest=hashlib.sha256(image.convert('RGB').crop((x,y,x+w,y+h)).tobytes()).hexdigest()
            orientation_crops.append({'stage':entry['stage'],'matches':digest==item['pixel_sha256'],'sha256':digest})
        checks['every_saved_orientation_present']=len(orientation_crops)==len(trace['ui_presentations'])
        checks['every_saved_orientation_crop_matches']=all(c['matches'] for c in orientation_crops)
        checks['both_orientation_stations']={p['station'] for p in packets}=={0,1}
        checks['moving_orientation_grid']=len({str(p['grid']) for p in packets if p['station']==1})>2
        checks['moving_hull_geometry']=stages['commander-settled']['quads'][1]['basis']!=stages['commander-stopped']['quads'][1]['basis']
        turret=[stages[name] for name in ('turret-mode','turret-right','turret-left')]
        checks['independent_turret_with_stationary_hull']=len({str(p['quads'][1]['basis']) for p in turret})==1 and len({str(p['quads'][2]['basis']) for p in turret})==3
    reticle_crops=[]
    if trace['profile']=='reticle':
        observation=trace['reticle_observation'];packets=[p['reticle'] for p in rows if p.get('reticle')]
        checks['all_reticle_entries_completed']=observation.get('entries',0)>0 and observation['entries']==observation.get('completed_draws')
        checks['no_reticle_rejections']=set(observation)<=set(('entries','completed_draws','presented_draws','frame_mismatches'))
        checks['reticle_presented_count']=len(packets)==observation.get('presented_draws')
        checks['reticle_visibility_gate_exercised']=observation.get('frame_mismatches',0)>0
        checks['reticle_same_page']=all(p['reticle']['page_offset']==p['page_offset'] for p in rows if p.get('reticle'))
        checks['both_reticle_colours']={p['color'] for p in packets}=={0,1}
        checks['moving_reticle_centres']=len({p['center_y'] for p in packets})>=3
        stages={}
        for sample in trace['ui_presentations']:
            item=rows[sample['frame_index']].get('reticle',{});stages[sample['stage']]=item
            if not item: continue
            x,y,w,h=item['rect']
            with Image.open(trace_path.parent/sample['image']) as image:
                actual=hashlib.sha256(image.convert('RGB').crop((x,y,x+w,y+h)).tobytes()).hexdigest()
            reticle_crops.append({'stage':sample['stage'],'matches':actual==item['pixel_sha256'],'sha256':actual})
        checks['saved_reticle_crops_match']=len(reticle_crops)>5 and all(c['matches'] for c in reticle_crops)
        checks['commander_has_no_graticule']=not stages['commander'] and not stages['commander-return']
        checks['thermal_colour_returns']=stages['thermal']['color']==1 and stages['thermal-off']['color']==0
        checks['zoom_changes_visible_projection']=stages['aim-stopped']['center_y']!=stages['zoom']['center_y']!=stages['zoom-again']['center_y']
    return {'checks':checks,'frames':len(trace['frames']),'text_observation':stats,
            'visible_runs':[{'kind':kind,'text':text,'frames':n} for (kind,text),n in sorted(counts.items())],
            'saved_crops':captures,'orientation_crops':orientation_crops,'reticle_crops':reticle_crops,'readiness_delays':readiness_delays,
            'inputs':[{'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
                      for path in (trace_path,baseline_path)],
            'scope':'bounded source presentation visibility and unchanged guest RAM/video/input; no complete-game or timing parity claim'}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--trace',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    result=verify(args.trace,args.baseline)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not all(result['checks'].values()): raise SystemExit(1)


if __name__=='__main__': main()
