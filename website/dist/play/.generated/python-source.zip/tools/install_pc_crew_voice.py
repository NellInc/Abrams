#!/usr/bin/env python3
"""Install the bounded PC crew set after fingerprinted, blinded wording QA.

This is an offline verification/install step. Automated QA is separate from
human listening approval. Numeric transcripts require a second, independent
spoken-number classification; numeric normalization alone is insufficient.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
try:
    from tools.check_crew_transcripts import normalized,wording_matches
    from tools.generate_crew_voice import validate_wav,pronounce_headings,PREFERRED
    from tools.pc_crew_voice import SCRIPT,DAMAGE,WARNINGS,RADIO,REMAINING
except ModuleNotFoundError as error:
    if error.name != 'tools': raise
    from check_crew_transcripts import normalized,wording_matches
    from generate_crew_voice import validate_wav,pronounce_headings,PREFERRED
    from pc_crew_voice import SCRIPT,DAMAGE,WARNINGS,RADIO,REMAINING

DIGITS='zero one two three four five six seven eight nine'.split()
ROOT=Path(__file__).resolve().parents[1]


def _repo_rel(path):
    # Receipts ship in packages: record repo-relative paths, never a developer's
    # absolute home path or a cwd-relative one that audit_pc_audio cannot resolve.
    path=Path(path).resolve()
    try:return str(path.relative_to(ROOT.resolve()))
    except ValueError:raise ValueError(f'source outside repository: {path}') from None


def check_take(voice,transcription,delivery=None):
    if transcription['audio_sha256']!=voice['sha256'] or transcription['expected']!=voice['performed_text']:
        raise ValueError('transcription custody mismatch')
    if wording_matches(transcription['transcript'],voice['performed_text']):return
    # Only space-separated single digits, never a whole-number transcript, can
    # use the separate phonetic classification to resolve recognizer formatting.
    match=re.fullmatch(r"(We've been hit[!,]? Bearing)\s+([0-9])\s+([0-9])\s+([0-9])[.!]?",transcription['transcript'],re.I)
    if not match or not delivery:raise ValueError('wording or number delivery unverified')
    words=[DIGITS[int(d)] for d in match.groups()[1:]]
    expanded=match[1]+' '+' '.join(words)
    if (normalized(expanded)!=normalized(voice['performed_text']) or
            delivery['audio_sha256']!=voice['sha256'] or
            delivery['number_delivery']!='individual_digits' or
            [('nine' if w=='niner' else w) for w in delivery['spoken_number_words']]!=words):
        raise ValueError('wording or number delivery mismatch')


def _generation(source,script_path):
    manifest_path=source/'manifest.json'
    manifest=json.loads(manifest_path.read_text())
    if manifest['script_sha256']!=hashlib.sha256(script_path.read_bytes()).hexdigest():raise ValueError('generation script changed')
    qa=source/'qa-first/transcription-check.json';numbers=source/'qa-bearing-delivery/number-delivery-check.json'
    report=json.loads(qa.read_text());delivery=json.loads(numbers.read_text()) if numbers.exists() else {}
    if report['results'].keys()!=manifest['voices'].keys():raise ValueError('QA coverage differs')
    return {'source':source,'script':json.loads(script_path.read_text()),'manifest':manifest,
            'qa':report,'delivery':delivery,'inputs':[f for f in (manifest_path,script_path,qa,numbers) if f.exists()]}


def prepare(source,script_path=SCRIPT,*,source_script=None,repair=None,additional=(),receipt_path=None):
    script=json.loads(script_path.read_text())
    # A repair may supersede an installed take only when custody says that take is what is installed.
    installed=json.loads(receipt_path.read_text())['voices'] if receipt_path and receipt_path.exists() else {}
    repaired=set()
    base=_generation(source,source_script or script_path)
    batches=[base];selected={name:base for name in base['manifest']['voices']}
    for source in additional:
        batch=_generation(source,source_script or script_path)
        names=batch['manifest']['voices'].keys()
        if not names or set(names)&set(selected):raise ValueError('duplicate or empty additional generation source')
        selected.update({name:batch for name in names});batches.append(batch)
    if selected.keys()!=script['cues'].keys():raise ValueError('catalogue coverage differs')
    if repair is not None:
        replacement=_generation(repair,script_path)
        names=replacement['manifest']['voices'].keys()
        if not names or not names<=selected.keys():raise ValueError('unknown/empty repair selection')
        selected.update({name:replacement for name in names});batches.append(replacement);repaired=set(names)
    voices={};payloads={};dest=ROOT/'godot/assets/audio'
    for name,batch in selected.items():
        if not re.fullmatch('pc_[a-z_]+',name):raise ValueError('unsafe PC cue')
        cue=script['cues'][name]
        if batch['script']['cues'].get(name)!=cue:raise ValueError('selected generation cue differs from current script')
        if batch['script']['roles'].get(cue['role'])!=script['roles'].get(cue['role']):raise ValueError('selected generation casting differs from current script')
        voice=batch['manifest']['voices'][name];folder=batch['source']
        raw=(folder/f'voice_{name}.wav').read_bytes();metrics=validate_wav(raw)
        if any(voice[k]!=v for k,v in metrics.items()):raise ValueError('generated WAV differs from receipt')
        if voice['text']!=cue['caption']:raise ValueError('caption differs')
        expected=cue['text' if voice['generator']==PREFERRED else 'caption']
        if voice['performed_text']!=pronounce_headings(expected):raise ValueError('performed text differs from script')
        transcript=batch['qa']['results'][name];delivery=batch['delivery'].get(name)
        check_take(voice,transcript,delivery)
        path=dest/f'voice_{name}.wav';previous={}
        if path.exists() and (current:=path.read_bytes())!=raw:
            current_sha=hashlib.sha256(current).hexdigest()
            if name not in repaired or (installed.get(name) or {}).get('sha256')!=current_sha:
                raise ValueError('refusing to replace different installed voice')
            previous={'previous_take_sha256':current_sha}
        payloads[path]=raw
        voices[name]=voice|previous|{'source_master':_repo_rel(folder/f'voice_{name}.wav'),
            'generation_script_sha256':batch['manifest']['script_sha256'],
            'processing':'Unmodified generated dry master','transcript_qa':transcript,
            'number_delivery_qa':delivery}
    receipt={'scope':script['scope'],'status':'Automated wording checked; digit delivery checked where required; human listening review pending',
             'script_sha256':hashlib.sha256(script_path.read_bytes()).hexdigest(),'voices':voices,
             'qa_inputs':[{'path':_repo_rel(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for batch in batches for f in batch['inputs']]}
    if 'revalidation' in base['qa']:receipt['qa_revalidation']=base['qa']['revalidation']
    return payloads,receipt


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True);p.add_argument('--dry-run',action='store_true')
    p.add_argument('--source-script',type=Path,help='Fingerprint-pinned original script when retaining unchanged takes')
    p.add_argument('--additional-source',type=Path,action='append',default=[],help='Disjoint fingerprinted partial batch completing this catalogue')
    p.add_argument('--repair-source',type=Path,help='Independently generated and blind-checked replacement subset from the current script')
    p.add_argument('--bank',choices=('crew','damage','warning','radio','remaining'),default='crew');a=p.parse_args()
    provenance=ROOT/'godot/assets/audio'/f'pc_{a.bank}_provenance.json'
    payloads,receipt=prepare(a.source,{'crew':SCRIPT,'damage':DAMAGE,'warning':WARNINGS,'radio':RADIO,'remaining':REMAINING}[a.bank],source_script=a.source_script,repair=a.repair_source,additional=a.additional_source,receipt_path=provenance)
    if not a.dry_run:
        for path,raw in payloads.items():path.write_bytes(raw)
        provenance.write_text(json.dumps(receipt,indent=2)+'\n')
    print(f'{len(payloads)} PC {a.bank} takes verified'+(' (dry run)' if a.dry_run else ' and installed'))


if __name__=='__main__':main()
