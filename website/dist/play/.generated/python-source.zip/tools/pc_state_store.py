"""Bounded, fingerprinted local checkpoints. No pickle or archive extraction."""
from __future__ import annotations
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import stat
import struct
import sys
import tempfile
import time
import zipfile
import zlib

MAX_STATE = 128 * 1024 * 1024
MAX_DISK = 64 * 1024 * 1024
MAX_RESUME = 32 * 1024 * 1024
OPTIONAL_LIMITS = {'observer.bin': 2 * 1024 * 1024}
LIMITS = {'state.bin': MAX_STATE, 'resume.json': MAX_RESUME, 'campaign.zip': MAX_DISK}
# zipfile passes decompression faults through unwrapped; report them as invalid data.
DAMAGED = (zlib.error, NotImplementedError, EOFError, RuntimeError, zipfile.BadZipFile, zipfile.LargeZipFile)

# Name-surrogate reparse tags; the stat module defines them only on Windows.
LINK_REPARSE_TAGS = (getattr(stat, 'IO_REPARSE_TAG_SYMLINK', 0xA000000C),
                     getattr(stat, 'IO_REPARSE_TAG_MOUNT_POINT', 0xA0000003))


def is_link(path):
    """Symlinks, plus Windows junctions, which Path.is_symlink() misses.

    Other reparse points (OneDrive placeholders, deduplicated files) are
    ordinary files and folders, so only the link tags count."""
    path = Path(path)
    if path.is_symlink(): return True
    try: info = os.lstat(path)
    except OSError: return False
    return (bool(getattr(info, 'st_file_attributes', 0) & stat.FILE_ATTRIBUTE_REPARSE_POINT)
            and getattr(info, 'st_reparse_tag', 0) in LINK_REPARSE_TAGS)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def sync_parent(path):
    # Windows' CRT cannot open directories for fsync. The temporary file is
    # still flushed before same-directory replacement on every platform.
    if os.name == 'nt': return
    directory = os.open(path, os.O_RDONLY)
    try: os.fsync(directory)
    finally: os.close(directory)

def atomic_write(path, raw, before_replace=None):
    path = Path(path)
    fd, name = tempfile.mkstemp(prefix='.' + path.name + '-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        # Runs only once the new bytes are durable, so a full disk or failed
        # write leaves everything it would touch unchanged.
        if before_replace: before_replace()
        os.replace(name, path)
        sync_parent(path.parent)
    finally:
        if os.path.exists(name): os.unlink(name)


def read_bounded(path, limit):
    with Path(path).open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit: raise ValueError('checkpoint file exceeds size limit')
    return raw


def validate_disk(raw):
    if not raw: return
    if len(raw) > MAX_DISK: raise ValueError('campaign overlay exceeds size limit')
    try: archive = zipfile.ZipFile(io.BytesIO(raw))
    except DAMAGED as error: raise ValueError(f'damaged campaign overlay: {error}') from error
    with archive:
        infos = archive.infolist()
        if len(infos) > 4096 or sum(i.file_size for i in infos) > MAX_DISK:
            raise ValueError('campaign overlay expands beyond size limit')
        names = [i.filename for i in infos]
        if len(names) != len(set(names)): raise ValueError('duplicate campaign member')
        for item in infos:
            name = item.filename.replace('\\', '/')
            if name.startswith('/') or '..' in name.split('/') or ':' in name or item.flag_bits & 1:
                raise ValueError('unsafe campaign archive member')
        try: bad = archive.testzip()
        except DAMAGED as error: raise ValueError(f'damaged campaign overlay: {error}') from error
        if bad is not None: raise ValueError('campaign overlay CRC mismatch')


def core_identity(core):
    """Return (checkpoint key, shipped-bytes hash) for a native core.

    Developer ID signing rewrites the core's bytes but not its code, and records
    the pre-signing hash in the adjacent build receipt. That identity is used
    only when the receipt's trace_sha256 pins exactly these shipped bytes (the
    receipt the core loader trusts, itself hash-checked by the signed payload
    manifest); anything else falls back to the bytes themselves."""
    actual = sha(Path(core).read_bytes())
    try: receipt = json.loads(read_bounded(Path(core).with_suffix('.json'), 65536))
    except (OSError, ValueError): return actual, actual
    if not isinstance(receipt, dict) or receipt.get('trace_sha256') != actual: return actual, actual
    unsigned = receipt.get('unsigned_trace_sha256')
    if isinstance(unsigned, str) and re.fullmatch('[0-9a-f]{64}', unsigned): return unsigned, actual
    return actual, actual


class StateStore:
    def __init__(self, saves, core, content, backend, overlay=None):
        # Checked before resolve(), which would follow a link or junction at the
        # saves folder itself. Ancestors are the launcher's to police (system
        # paths such as macOS /var are links), not the store's.
        if is_link(saves) or is_link(Path(saves) / 'states'):
            raise ValueError('state directory must not be a symlink or junction')
        self.root = Path(saves).resolve() / 'states'
        if is_link(self.root): raise ValueError('state directory must not be a symlink or junction')
        self.root.mkdir(parents=True, exist_ok=True)
        identity, actual = core_identity(core)
        self.compatibility = {'schema': 1, 'backend': backend,
            'core_sha256': identity, 'content_sha256': sha(Path(content).read_bytes()),
            'platform': sys.platform, 'machine': platform.machine(),
            'byteorder': sys.byteorder, 'pointer_bits': struct.calcsize('P') * 8,
            'options': 'abrams-ega-normal-386-3000-v1'}
        # Slots written before checkpoints used the pre-signing identity were
        # keyed on these exact signed bytes; they remain readable.
        self.accepted = [self.compatibility, self.compatibility | {'core_sha256': actual}]
        # A snapshot session keeps its slots here but its live overlay elsewhere.
        if is_link(overlay or saves): raise ValueError('campaign overlay folder must not be a symlink or junction')
        self.disk = Path(overlay or saves).resolve() / (Path(content).stem + '.pure.zip')
        if is_link(self.disk): raise ValueError('campaign overlay must not be a symlink or junction')

    def path(self, slot):
        if type(slot) is not int or not 0 <= slot <= 5: raise ValueError('slot must be 0 to 5')
        path = self.root / f'slot-{slot}.zip'
        if is_link(path): raise ValueError('slot must not be a symlink or junction')
        return path

    def read(self, slot, previous=False):
        path = self.path(slot)
        if previous:
            # The archive write() kept when this numbered slot was overwritten.
            if not 1 <= slot <= 5: raise ValueError('Only numbered slots keep an overwritten archive')
            path = path.with_suffix('.previous.zip')
            if is_link(path): raise ValueError('slot must not be a symlink or junction')
        if not path.exists(): raise ValueError(f'Slot {slot} has no overwritten archive' if previous else f'Slot {slot} is empty')
        raw = read_bounded(path, sum(LIMITS.values()) + sum(OPTIONAL_LIMITS.values()) + 65536)
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as archive:
                infos = archive.infolist()
                names = {i.filename for i in infos}
                if (len(infos) != len(names) or not {*LIMITS, 'manifest.json'} <= names
                        or names - {*LIMITS, *OPTIONAL_LIMITS, 'manifest.json'}):
                    raise ValueError('invalid checkpoint members')
                for item in infos:
                    if item.file_size > ((LIMITS | OPTIONAL_LIMITS).get(item.filename, 65536)) or item.flag_bits & 1:
                        raise ValueError('checkpoint member exceeds limit or is encrypted')
                manifest = json.loads(archive.read('manifest.json'))
                if not isinstance(manifest, dict): raise ValueError('invalid checkpoint manifest')
                if manifest.get('compatibility') not in self.accepted:
                    raise ValueError('Checkpoint belongs to a different core, game, or platform')
                files = {name: archive.read(name) for name in (LIMITS | OPTIONAL_LIMITS) if name in names}
        except DAMAGED as error: raise ValueError(f'damaged checkpoint: {error}') from error
        if not files['state.bin']: raise ValueError('empty native checkpoint')
        if manifest.get('files') != {name: {'size': len(data), 'sha256': sha(data)} for name, data in files.items()}:
            raise ValueError('Checkpoint integrity check failed')
        resume = json.loads(files['resume.json'])
        if (not isinstance(resume, dict) or type(resume.get('frame')) is not int or resume['frame'] < 0
                or type(resume.get('sequence')) is not int or resume['sequence'] < 0
                or not isinstance(resume.get('keys'), list) or len(resume['keys']) > 16
                or not isinstance(resume.get('packet'), dict)
                or not isinstance(resume.get('ram_sha256'), str)
                or len(resume['ram_sha256']) != 64
                or any(c not in '0123456789abcdef' for c in resume['ram_sha256'])
                or any(not isinstance(k, str) for k in resume['keys'])
                or len(set(resume['keys'])) != len(resume['keys'])):
            raise ValueError('invalid checkpoint resume metadata')
        validate_disk(files['campaign.zip'])
        return manifest, files

    def write(self, slot, capture):
        files = {name: read_bounded(Path(capture) / name, limit) for name, limit in LIMITS.items()}
        files.update({name: read_bounded(Path(capture) / name, limit)
                      for name, limit in OPTIONAL_LIMITS.items() if (Path(capture) / name).exists()})
        validate_disk(files['campaign.zip'])
        resume = json.loads(files['resume.json'])
        packet = resume['packet']
        program = packet.get('program') or {}
        manifest = {'compatibility': self.compatibility, 'saved_at': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime()),
                    'program': program.get('name', 'Original game'), 'sequence': resume['sequence'],
                    'files': {name: {'size': len(data), 'sha256': sha(data)} for name, data in files.items()}}
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('manifest.json', json.dumps(manifest))
            for name, raw in files.items(): archive.writestr(name, raw)
        target = self.path(slot)
        # Only numbered slots offer their overwritten archive. Recovery slot 0 is
        # replaced on every load and its predecessor is never listed or read.
        def keep_overwritten():
            if not slot or not target.exists(): return
            # A damaged or incompatible slot could never be loaded back, so it
            # must not replace an overwritten archive that still can.
            try: self.read(slot)
            except (ValueError, OSError): return
            atomic_write(target.with_suffix('.previous.zip'), read_bounded(target, sum(LIMITS.values()) + sum(OPTIONAL_LIMITS.values()) + 65536))
        atomic_write(target, buffer.getvalue(), keep_overwritten)
        self.read(slot)

    def slots(self):
        result = []
        for slot in range(6):
            row = {'slot': slot, 'exists': False, 'valid': False,
                   'label': 'Before last load' if slot == 0 else f'Slot {slot}'}
            try:
                row['exists'] = (self.root / f'slot-{slot}.zip').exists()
                if row['exists']:
                    manifest, _ = self.read(slot)
                    row.update(valid=True, saved_at=manifest['saved_at'], program=manifest['program'])
            # One damaged file must never break the listing (or the host that sends it).
            except Exception as error: row['message'] = str(error) or type(error).__name__
            # Listed only when it reads back whole; a damaged or incompatible
            # overwritten archive is simply absent and never affects the slot row.
            if slot:
                try:
                    if (self.root / f'slot-{slot}.previous.zip').exists():
                        row['previous_saved_at'] = self.read(slot, previous=True)[0]['saved_at']
                except Exception: pass
            result.append(row)
        return result

    def install_disk(self, raw):
        validate_disk(raw)
        if is_link(self.disk): raise ValueError('campaign overlay must not be a symlink or junction')
        if raw: atomic_write(self.disk, raw)
        elif self.disk.exists(): self.disk.unlink()
