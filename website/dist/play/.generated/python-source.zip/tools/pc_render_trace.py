"""Read-only original draw collection and EGA scanout/page attribution.

The live path retains bounded history. Guest writes and replacement simulation
are deliberately absent. Video tags follow the core's triple-buffer slots.
"""
from __future__ import annotations
from collections import deque
import base64
import ctypes as C
import hashlib
import io
from pathlib import Path
import struct
from PIL import Image

try:
    from tools.pc_vehicle_math import compose, object_matrix, orientation_mode, primitive_camera_vertices
    from tools.inspect_shapes import inspect_shapes
    from tools.inspect_scenarios import decode_resource
    from tools.pc_materials import read_materials, material_pixel
    from tools.pc_bitmaps import decode_bitmaps, read_ega_bitmap, verify_loaded_effects
    from tools.pc_audio_events import AudioEvents
    from tools.pc_guided_launch import GuidedLaunches, receipt_capability
    from tools.pc_orientation import OrientationRuns
    from tools.pc_reticle import ReticleRuns
    from tools.pc_reticle_target import TargetBoxRuns
    from tools.pc_dynamic_map import MapRuns
    from tools.pc_text_trace import TextRuns
    from tools.pc_strut_trace import StrutDraws
    from tools.pc_live_state import SIM_SHA256
    from tools.pc_message_events import visible_messages
    from tools.pc_plate_trace import PlateLoads, PLATE_IDS
    from tools.pc_trace_windows import WINDOW_EVENTS, event_ram, receipt_window_bundles
except ModuleNotFoundError as error:
    if error.name != 'tools': raise
    from pc_vehicle_math import compose, object_matrix, orientation_mode, primitive_camera_vertices
    from inspect_shapes import inspect_shapes
    from inspect_scenarios import decode_resource
    from pc_materials import read_materials, material_pixel
    from pc_bitmaps import decode_bitmaps, read_ega_bitmap, verify_loaded_effects
    from pc_audio_events import AudioEvents
    from pc_guided_launch import GuidedLaunches, receipt_capability
    from pc_orientation import OrientationRuns
    from pc_reticle import ReticleRuns
    from pc_reticle_target import TargetBoxRuns
    from pc_dynamic_map import MapRuns
    from pc_text_trace import TextRuns
    from pc_strut_trace import StrutDraws
    from pc_live_state import SIM_SHA256
    from pc_message_events import visible_messages
    from pc_plate_trace import PlateLoads, PLATE_IDS
    from pc_trace_windows import WINDOW_EVENTS, event_ram, receipt_window_bundles

ROOT = Path(__file__).resolve().parents[1]
CALLBACK = C.CFUNCTYPE(None, C.c_uint32, C.POINTER(C.c_uint16), C.c_void_p, C.c_uint32, C.c_uint32)
FULL_UI_BYTES = bytes(255) + b'\xff'
EMPTY_DRIVER_MASK = bytes(320 * 200 * 3)
INVALID_DRIVER_HIGH = bytes(int(i > 127) for i in range(256))
INVALID_PLATE = bytes(int(i > len(PLATE_IDS)) for i in range(256))
# Decoded original resources, keyed by their exact bytes. They are immutable
# and shared read-only; every attachment still starts with empty run state.
SOURCE_CACHE = {}


def cached_source(path, decode):
    raw = path.read_bytes()
    key = (decode.__name__, hashlib.sha256(raw).hexdigest())
    if key not in SOURCE_CACHE: SOURCE_CACHE[key] = decode(raw)
    return SOURCE_CACHE[key]


def effect_table(raw):
    return decode_bitmaps(decode_resource(raw))


def shape_table(raw):
    """Source shapes plus first-match offset lookups for primitives and commands."""
    shapes = inspect_shapes(decode_resource(raw))['shapes']
    primitives, commands = [], []
    for shape in shapes:
        primitives.append({}); commands.append({})
        for p in shape['primitives']: primitives[-1].setdefault(p['offset'], p)
        for c in shape['opaque_commands']: commands[-1].setdefault(c['offset'], c)
    return shapes, primitives, commands


def prewarm():
    """Decode every pinned SIM source into the shared caches before the first
    SIM attach, so entering a mission never pays the cold decode inside a
    bridge step. Hosts call this once at startup; nothing observes the guest.
    Each later attach still reads and hash-checks the exact source bytes."""
    cached_source(ROOT / 'GAME/EFFECTS.BMP', effect_table)
    cached_source(ROOT / 'GAME/SHAPE.TBL', shape_table)
    StrutDraws(ROOT / 'GAME', PlateLoads(ROOT / 'GAME'))


class Collector:
    def __init__(self, reader, output=None, *, history_limit=3000, loop_diagnostics=False,
                 window_bundles=False):
        self.reader, self.output = reader, output
        # Packet format of SIM events 26/28/29, as the trace core's receipt
        # declares it (pc_trace_windows). attach() reads it from the core.
        self.window_bundles = window_bundles
        self.loop_diagnostics = loop_diagnostics
        self.loop_diagnostic = None
        self.loop_sequence = 0
        self.active = None
        self.indexed_pass, self.active_objects, self.active_dynamic = None, {}, set()
        self.passes = deque(maxlen=history_limit)
        self.completed_count = 0
        self.pages = {}
        self.drawing_pages = set()
        # Decoder gaps the original's frames show as its own pixels, counted.
        self.skipped_passes = 0
        self.vertex_mismatches = 0
        self.scanout = None
        self.ui_mask_slot = None
        self.plate_mask_slot = None
        self.scanout_ui_bits = b''
        self.buffers = {}
        self.presented = None
        self.mask_png_cache = {}
        self.scanout_sequence = 0
        self.current = None
        self.composition_cx = None
        self.palette_rgb = None
        self.backgrounds = {}
        self.background_page = None
        self.error = None
        self.sequence = 0
        self.audio = AudioEvents()
        self.orientation = OrientationRuns()
        self.reticle = ReticleRuns()
        self.target_box = TargetBoxRuns()
        self.dynamic_map = MapRuns()
        self.text = TextRuns(ROOT / "GAME")
        self.plates = PlateLoads(ROOT / 'GAME')
        self.struts = StrutDraws(ROOT / 'GAME', self.plates)
        self.claim_strut = None
        self.claim_motor_pool = None
        self.vertices_checked = 0
        self.effects = cached_source(ROOT / 'GAME/EFFECTS.BMP', effect_table)
        self.effect_pixels_checked = 0
        self.shapes, self.shape_primitives, self.shape_commands = cached_source(ROOT / 'GAME/SHAPE.TBL', shape_table)
        self.guided = GuidedLaunches(shapes=self.shapes)
        self.callback = CALLBACK(self.observe)

    def observe(self, event, registers, data, offset, length):
        try: raw = C.string_at(data, length)
        except Exception as error:
            self.guided.pending = None
            if self.error is None: self.error = error
            return
        self.observe_packet(event, registers[:12], raw, offset)

    def observe_packet(self, event, registers, raw, offset):
        """Consume an exact native callback packet, including its original bytes."""
        guided_launch = self.guided.observe(event, registers, raw, offset, self.presented) if not self.error else None
        if event in (59,60): return
        if event == 56:
            try:
                self.loop_diagnostic = None
                if not self.loop_diagnostics: return
                state = self.reader.read_loop_end(raw, registers, offset)
                if self.active is not None: raise ValueError('loop diagnostic overlaps an original draw pass')
                if state is None: return
                self.loop_sequence += 1
                drawing = self.passes[-1] if self.passes else None
                diagnostic_state = {k:v for k,v in state.items() if k != 'world'}
                if state.get('camera'):
                    diagnostic_state['camera'] = dict(state['camera'], sampling=
                        'observed at original 0000:0e85 loop end; video pairing and universal atomicity unproven')
                self.loop_diagnostic = {
                    'schema': 1, 'boundary': '0000:0e85', 'sequence': self.loop_sequence,
                    'sampling': 'read-only loop end; independent of submitted framebuffer',
                    'video_paired': False, 'ram_sha256': hashlib.sha256(raw).hexdigest(),
                    'registers': list(registers),
                    'state': diagnostic_state,
                    'world_origin': state['world']['window_origin'],
                    'last_completed_draw': {k:drawing[k] for k in
                        ('sequence','page_offset','start_ram_sha256')} if drawing else None}
            except Exception as error:
                if self.error is None: self.error = error
            return
        try:
            if event == 25:
                self.audio.observe(raw, text_sequence=self.text.sequence, guided_launch=guided_launch)
                return
            if event in (10, 11, 12, 19, 24, 31):
                self.observe_video(event, offset, raw, registers)
                return
            regs = dict(zip(('ax','bx','cx','dx','si','di','bp','sp','cs','ds','es','ss'), registers[:12]))
            # The one decode point for native and Web SIM window bundles. Readers
            # keep their exact 640 KiB gates; unsent bytes read as zero. The
            # declared format is enforced both ways (fail closed).
            if event in WINDOW_EVENTS: raw = event_ram(raw, self.window_bundles)
            if event in (43,44,45):
                if event==43: self.dynamic_map.begin(raw)
                elif event==44: self.dynamic_map.line(raw)
                else: self.dynamic_map.finish(raw,offset)
                return
            if event in (40,41,42):
                if event==40: self.target_box.begin(raw,regs)
                elif event==41: self.target_box.line(raw)
                else: self.target_box.finish(raw)
                return
            if event in (37,38,39):
                if event==37: self.reticle.begin(raw,regs)
                elif event==38: self.reticle.line(raw)
                else: self.reticle.finish(raw)
                return
            if event in (33,34,35,36):
                if event==33: self.orientation.begin(raw,regs)
                elif event==34: self.orientation.quad(raw)
                elif event==35: self.orientation.finish(raw)
                else: self.orientation.line(raw)
                return
            if event == 29:
                self.struts.begin(raw, regs, offset)
                return
            if event == 30:
                claim = self.struts.finish(raw, offset)
                if claim:
                    plate,mask = claim
                    buffer = (C.c_uint8*len(mask)).from_buffer_copy(mask)
                    if not self.claim_strut(offset,plate,buffer,len(mask)):
                        raise ValueError('native strut provenance claim rejected')
                return
            if event == 32:
                if self.plates.verify_motor_pool(raw,offset):
                    if not self.claim_motor_pool(offset):
                        raise ValueError('native motor-pool provenance claim rejected')
                return
            if event == 28:
                self.text.messages.observe(raw, regs, offset)
                return
            if event == 26:
                self.text.begin(raw, regs)
                return
            if event == 27:
                self.text.finish(raw)
                return
            if event in (20, 21, 22):
                self.plates.observe(event, raw, regs['ax'])
                return
            if event == 23: raise ValueError(f'unsupported native plate observation: {offset}')
            def window(at, size):
                # Python would silently wrap a negative index to the buffer tail.
                index = at - offset
                if index < 0 or index + size > len(raw):
                    raise ValueError(f'event {event} read {at:#x}+{size} outside native window {offset:#x}+{len(raw):#x}')
                return index
            def word(at): return struct.unpack_from('<H', raw, window(at, 2))[0]
            def words(at, n): return list(struct.unpack_from('<' + 'h' * n, raw, window(at, 2 * n)))
            def byte(at): return raw[window(at, 1)]
            if event == 14:
                if len(raw) != 64: raise ValueError('unsupported palette snapshot')
                self.palette_rgb = [list(raw[i:i + 3]) for i in range(0, 64, 4)]
                return
            if event == 13:
                page = (word(0x35A8) - 0xA000) * 16
                self.pages.pop(page, None)
                self.drawing_pages.add(page)
                self.background_page = page
                self.backgrounds[page] = None
                if self.scanout and self.scanout['page_offset'] == page:
                    self.scanout['draw_pass'] = None
                    self.scanout['reason'] = 'displayed page redrawn during scanout'
                return
            if event == 57:
                # The native hook saw 340b called by a non-world caller, such as
                # the destroyed-GPS black panel after the world pass. Its pixels
                # are UI-owned; completed passes and backgrounds stay unchanged.
                self.background_page = None
                return
            if event in (15, 16) and self.background_page is None:
                return
            if event == 15:
                upper, lower = struct.unpack('<HH', raw)
                self.backgrounds[self.background_page] = {'kind': 'horizon',
                    'line': [[regs['si'], regs['di']], [regs['bx'], regs['cx']]],
                    'colors': [upper & 255, lower & 255]}
                return
            if event == 16:
                self.backgrounds[self.background_page] = {'kind': 'solid', 'color': regs['dx'] & 255}
                return
            if event == 9:
                return  # page-register write is observed; scanout latch is authoritative
            if event == 1:
                if self.active is not None: raise ValueError('nested original draw pass')
                self.sequence += 1
                state = self.reader.read(raw)
                if not state or not state['camera']:
                    # read_camera declines a renderer state outside its decoder
                    # (for example a queued pointer not yet allocated). Event 13
                    # already marked this page as being drawn, so scanout shows
                    # the original pixels until a later complete pass on it.
                    self.skipped_passes += 1
                    return
                state['camera']['sampling'] = 'observed at original drawing callback entry; not a logic-tick claim'
                self.guided.freeze(raw, state['load_segment'], self.sequence)
                ds = state['load_segment'] * 16 + 0x19E00
                self.sine = list(struct.unpack_from('<256h', raw, ds + 0x1D9C))
                self.cosine = list(struct.unpack_from('<256h', raw, ds + 0x1E1C))
                self.active = {'sequence': self.sequence, 'camera': state['camera'], 'objects': [],
                    'start_ram_sha256': hashlib.sha256(raw).hexdigest(), 'world': state['world'],
                    'page_offset': (struct.unpack_from('<H', raw, ds + 0x35A8)[0] - 0xA000) * 16,
                    'unsupported': []}
                self.active['materials'] = read_materials(raw, ds)
                self.active['palette_rgb'] = self.palette_rgb
                self.active['background'] = self.backgrounds.get(self.active['page_offset'])
                if self.sequence == 1:
                    loaded = verify_loaded_effects(raw, ds, self.effects)
                    self.effect_pixels_checked = sum(p['width'] * p['height'] for p in loaded)
                if self.sequence == 1 and self.output: (self.output / 'first-render.bin').write_bytes(raw)
                self.current = None
                self.composition_cx = None
                return
            if self.active is None: return
            if event == 7:
                # Every root resets context, including sprite-only roots which
                # never execute the matrix-ready hook.
                self.current = None
                self.composition_cx = None
                if raw[0] & 128:
                    obj, dynamic = self.world_object(regs['bx'])
                    if obj is None:
                        # Decoder gap, not provenance: the pass shows original pixels.
                        self.active['unsupported'].append({'kind': 'unknown_sprite_object', 'pointer': regs['bx']})
                        return
                    self.current = {'kind': 'sprite', 'pointer': regs['bx'], 'root': regs['di'],
                        'shape_index': obj['shape_index'], 'bitmap_index': raw[1], 'sprite_status': 'pending',
                        'dynamic_instance': dynamic,
                        'polygons': []}
                    self.active['objects'].append(self.current)
            elif event == 17:
                if not self.current or self.current.get('kind') != 'sprite':
                    self.active['unsupported'].append({'kind': 'unattributed_bitmap'})
                    return
                ds, stack = regs['ds'] * 16, regs['ss'] * 16 + regs['bp']
                index, x, y = struct.unpack_from('<Hhh', raw, stack + 6)
                if index != self.current['bitmap_index'] or index >= len(self.effects):
                    raise ValueError('original bitmap selection differs from root')
                source = self.effects[index]
                bitmap = read_ega_bitmap(raw, ds, regs['bx'])
                if any(bitmap[k] != source[k] for k in ('width', 'height', 'pixels')):
                    raise ValueError('observed bitmap differs from source resource')
                if bitmap['opaque'] != [p != 0 for p in source['pixels']]:
                    raise ValueError('observed bitmap transparency differs from source resource')
                if raw[ds + 0x359F] != 15:
                    self.current['sprite_status'] = 'unsupported-plane-mask'
                    self.active['unsupported'].append({'kind': 'bitmap_plane_mask', 'value': raw[ds + 0x359F]})
                    return
                clip = list(struct.unpack_from('<4h', raw, ds + 0x3593))
                # The driver's clip storage is left/right/top/bottom.
                self.current['sprite'] = bitmap | {'index': index, 'origin': [x, y],
                    'clip': [clip[0], clip[2], clip[1], clip[3]]}
                self.current['sprite_status'] = 'observed'
            elif event == 18:
                if self.current and self.current.get('kind') == 'sprite' and self.current['sprite_status'] == 'pending':
                    self.current['sprite_status'] = 'rejected-before-blit'
            elif event in (8,46,47,48):
                self.observe_round_form(event, regs, raw, offset)
            elif event == 5:
                self.composition_cx = regs['cx']
            elif event == 2:
                pointer = word(0x12CC)
                obj, dynamic = self.world_object(pointer)
                if obj is None:
                    self.active['unsupported'].append({'kind': 'unknown_object', 'pointer': pointer})
                    self.composition_cx = None
                    return
                matrix = words(word(0x1CDA), 9)
                self.current = {'pointer': pointer, 'shape_index': obj['shape_index'], 'root': regs['di'],
                    'dynamic_instance': dynamic,
                    'static_path': byte(0x1CDF), 'matrix_mode': byte(0x1CDE), 'matrix': matrix,
                    'view_origin': words(0x1426, 3), 'world_delta': words(0x142C, 3),
                    'packed_shift': byte(0x1425), 'composition_cx': self.composition_cx,
                    'primitive_ids': [], 'polygons': [], 'round_forms': [], 'draw_order': []}
                if not self.current['static_path']:
                    basis = object_matrix(obj['orientation_u8'], self.sine, self.cosine)
                    expected, mode = compose(basis, orientation_mode(obj['orientation_u8']),
                        self.active['camera']['matrix_q14_columns'], self.active['camera']['matrix_mode'], self.composition_cx)
                    if (expected, mode) != (matrix, self.current['matrix_mode']):
                        # Our composition disagrees with the original's: never present it.
                        self.active['unsupported'].append({'kind': 'composition_mismatch', 'pointer': pointer})
                        self.current = None
                        self.composition_cx = None
                        return
                self.active['objects'].append(self.current)
                self.composition_cx = None
            elif event == 3 and self.current and self.current.get('kind') != 'sprite':
                self.current['primitive_ids'].append(regs['si'])
            elif event == 6 and self.current and self.current.get('kind') != 'sprite':
                count = word(0x1A69)
                if not 0 <= count <= 16:
                    self.active['unsupported'].append({'kind': 'polygon_buffer_length', 'count': count})
                    return
                shape = self.shapes[self.current['shape_index']]
                primitive_id = self.current['primitive_ids'][-1] if self.current['primitive_ids'] else None
                primitive = self.shape_primitives[self.current['shape_index']].get(primitive_id)
                if primitive is None:
                    self.active['unsupported'].append({'kind': 'unknown_primitive', 'shape_index': shape['index'], 'primitive': primitive_id})
                    return
                vertices = primitive_camera_vertices(shape, primitive, self.current)
                for encoded, expected in zip(primitive['encoded_indices'], vertices):
                    index = (encoded & 127) * 2
                    actual = [words(at + index, 1)[0] for at in (0x1519, 0x1619, 0x1719)]
                    if actual != expected:
                        # Reconstruction disagrees with the original's transformed vertex.
                        self.vertex_mismatches += 1
                        self.active['unsupported'].append({'kind': 'vertex_mismatch', 'shape_index': shape['index'], 'reference': encoded})
                        return
                    self.vertices_checked += 1
                self.current.setdefault('draw_order', []).append({'kind':'polygon','index':len(self.current['polygons'])})
                self.current['polygons'].append({'primitive': self.current['primitive_ids'][-1] if self.current['primitive_ids'] else None,
                    'colors': [byte(0x359E), byte(0x359D)],
                    'fill_mode': byte(0x359C),
                    'camera_vertices': vertices,
                    'pixels': list(map(list, zip(words(0x1A29, count), words(0x1A49, count))))})
            elif event == 6:
                self.active['unsupported'].append({'kind': 'unattributed_polygon'})
            elif event == 4:
                for obj in self.active.get('objects', []):
                    if any(form['status'] in ('pending','observing') for form in obj.get('round_forms', [])):
                        self.active['unsupported'].append({'kind':'incomplete_round_form','pointer':obj['pointer']})
                    if obj.get('sprite_status') == 'pending':
                        self.active['unsupported'].append({'kind': 'incomplete_sprite', 'pointer': obj['pointer']})
                self.passes.append(self.active)
                self.completed_count += 1
                self.pages[self.active['page_offset']] = self.active
                self.drawing_pages.discard(self.active['page_offset'])
                self.active = None
        except Exception as error:
            # Keep the root cause; later events in the same native call cascade from it.
            if self.error is None: self.error = error
            self.active = None
            self.current = None


    def world_object(self, pointer):
        """Pointer lookup for events 2/7, indexed once per active pass.

        The first static entry wins, as the former linear scan did; dynamic
        membership is a separate test, so a pointer in both pools keeps both.
        """
        if self.indexed_pass is not self.active:
            world = self.active['world']
            self.active_objects = {}
            for name in ('dynamic', 'static'):
                for o in reversed(world[name]): self.active_objects[o['pointer']] = o
            self.active_dynamic = {o['pointer'] for o in world['dynamic']}
            self.indexed_pass = self.active
        return self.active_objects.get(pointer), pointer in self.active_dynamic

    def observe_round_form(self, event, regs, raw, offset):
        """Consume only observed original round-form calls, never rebuild poses."""
        obj = self.current
        if not obj or obj.get('kind') == 'sprite':
            if event == 8:
                self.active['unsupported'].append({'kind':'opaque_command','command_offset':regs['di'],
                    'pointer':obj['pointer'] if obj else None,'command':list(raw)})
            else:
                self.active['unsupported'].append({'kind':'unattributed_round_form','event':event})
            return
        forms = obj.setdefault('round_forms', [])
        if event == 8:
            if len(raw) != 4: raise ValueError('invalid round-form command length')
            shape = self.shapes[obj['shape_index']]
            command = self.shape_commands[obj['shape_index']].get(regs['di'])
            if command is None or bytes.fromhex(command['hex']) != raw:
                raise ValueError('round-form command differs from source')
            if forms and forms[-1]['status'] in ('pending','observing'):
                raise ValueError('nested round-form observation')
            if len(forms) >= 32:
                self.active['unsupported'].append({'kind': 'round_form_count', 'pointer': obj['pointer']})
                forms.append({'command_offset':regs['di'],'command':list(raw),'status':'unsupported','spans':[]})
                return
            forms.append({'command_offset':regs['di'],'command':list(raw),'status':'pending','spans':[]})
            return
        if not forms or forms[-1]['command_offset'] != offset:
            raise ValueError('round-form event lacks matching command')
        form=forms[-1]
        if form['status'] == 'unsupported':
            return  # already recorded; the pass shows original pixels
        if event == 47:
            if form['status'] == 'pending': form['status']='rejected-before-raster'
            elif form['status'] == 'observing': form['status']='observed'
            else: raise ValueError('duplicate round-form return')
            return
        expected_length=30 if event==46 else 18
        if len(raw)!=expected_length: raise ValueError('invalid round-form event length')
        values=list(struct.unpack('<'+'H'*(len(raw)//2),raw))
        if values[:3] != [1,offset,obj['pointer']]:raise ValueError('round-form owner/schema mismatch')
        signed=lambda x:(x+32768)%65536-32768
        if event==46:
            if form['status']!='pending':raise ValueError('duplicate round-form raster entry')
            if values[10]!=self.active['page_offset']:raise ValueError('round-form page mismatch')
            if list(raw[26:30])!=form['command']:raise ValueError('round-form raster command mismatch')
            if values[12]&255 != 1:
                # A decoder limit, not provenance: the pass shows original pixels.
                form['status']='unsupported'
                self.active['unsupported'].append({'kind':'unclipped_round_form','pointer':obj['pointer']})
                return
            # Impossible values from the native hook stay fatal (contract).
            if values[11]&255 > 15 or values[11]>>8 > 15:raise ValueError('invalid round-form color')
            clip=list(map(signed,values[6:10]))
            if not (0<=clip[0]<=clip[2]<320 and 0<=clip[1]<=clip[3]<200):raise ValueError('invalid round-form clip')
            radius=min(max(0,signed(values[3])),102)
            form.update({'status':'observing','center':list(map(signed,values[4:6])),
                         'radius_raw':values[3],'radius':radius,'horizontal_radius':radius+radius//4,
                         # Same order as polygon colors: [DS:359E, DS:359D].
                         'colors':[values[11]>>8,values[11]&255],'fill_mode':values[12]>>8,
                         'clip':clip,'page_offset':values[10]})
            obj.setdefault('draw_order',[]).append({'kind':'round_form','index':len(forms)-1})
        else:
            if form['status']!='observing':raise ValueError('round-form span outside raster lifetime')
            if values[6]!=form['page_offset']:raise ValueError('round-form span page mismatch')
            y,left=map(signed,values[3:5]);width=values[5]
            if width>320:raise ValueError('round-form span too wide')
            clip=form['clip'];right=min(left+width,clip[2]+1);left=max(left,clip[0])
            if clip[1]<=y<=clip[3] and left<right:
                if len(form['spans'])>=64000:raise ValueError('too many round-form spans')
                # The original span receives AX/DX pattern words. Convert to
                # exact palette indices so a renderer need not decode words.
                # For one row the colour depends only on x parity: a solid or
                # equal-nibble span is one {'color'} run; a real dither is one
                # record whose 'colors' are [even x, odd x] by absolute screen
                # x, so clipping cannot shift the phase. Expanded per pixel by
                # pc_modern_source_commands.gd round_runs().
                words=values[7:9];even,odd=material_pixel(words,0,y),material_pixel(words,1,y)
                if even==odd or right-left==1:
                    form['spans'].append({'y':y,'left':left,'right':right,'color':odd if left&1 else even})
                else:
                    form['spans'].append({'y':y,'left':left,'right':right,'colors':[even,odd]})

    @staticmethod
    def binary_mask(raw):
        return raw.count(0) + raw.count(255) == len(raw)

    @staticmethod
    def outside_ui(raw, ui):
        # Each byte is an independent bit lane. Only exactly 255 grants UI
        # ownership, preserving the old predicate even for malformed UI bytes.
        owned = ui.translate(FULL_UI_BYTES)
        return bool(int.from_bytes(raw, 'little') & ~int.from_bytes(owned, 'little'))

    @staticmethod
    def safe_driver_mask(raw, ui):
        # Exact full-byte proof of no driver writes. No offsets or ownership
        # bits exist in this common non-driver frame, regardless of UI values.
        if raw == EMPTY_DRIVER_MASK: return True
        low, high, mask = raw[0::3], raw[1::3], raw[2::3]
        if not Collector.binary_mask(mask) or high.translate(INVALID_DRIVER_HIGH).count(1): return False
        if Collector.outside_ui(mask, ui): return False
        offsets = int.from_bytes(low, 'little') | int.from_bytes(high, 'little')
        return not (offsets & ~int.from_bytes(mask, 'little'))

    def mask_png(self, event, raw):
        # Cache encoding only, after the caller's current-frame guards. Exact
        # immutable byte equality, one entry per mask kind, no unbounded history.
        mode = {19: 'L', 24: 'L', 31: 'RGB'}[event]
        raw = bytes(raw)
        previous = self.mask_png_cache.get(event)
        if previous is not None and previous[0] == raw:
            return previous[1]
        png = io.BytesIO()
        Image.frombytes(mode, (320,200), raw).save(png, format='PNG', compress_level=1)
        encoded = base64.b64encode(png.getvalue()).decode('ascii')
        self.mask_png_cache[event] = (raw, encoded)
        return encoded

    def observe_video(self, event, slot_or_page, raw, registers):
        if event == 10:
            self.ui_mask_slot = None
            self.plate_mask_slot = None
            self.scanout_ui_bits = b''
            self.scanout_sequence += 1
            page = slot_or_page
            drawing = self.pages.get(page) if page not in self.drawing_pages else None
            self.scanout = {'scanout_sequence': self.scanout_sequence, 'page_offset': page,
                '_text_candidates': self.text.scanout(page),
                '_orientation_candidate': self.orientation.scanout(page),
                '_reticle_candidate': self.reticle.scanout(page),
                '_target_box_candidate': self.target_box.scanout(page),
                '_dynamic_map_candidate': self.dynamic_map.scanout(page),
                'draw_pass': drawing, 'reason': None if drawing else 'no complete observed pass for scanned page',
                'palette_rgb': [list(raw[i:i + 3]) for i in range(0, 64, 4)] if len(raw) == 64 else None}
        elif event == 19:
            if slot_or_page not in range(3): raise ValueError('unknown core framebuffer slot')
            if raw and len(raw) != 320 * 200: raise ValueError('unsupported UI mask dimensions')
            if not self.binary_mask(raw): raise ValueError('invalid UI provenance mask')
            self.ui_mask_slot = slot_or_page
            self.scanout_ui_bits = raw
            if self.scanout:
                self.scanout['ui_overlay'] = None
                if raw:
                    self.scanout['ui_overlay'] = {'width': 320, 'height': 200,
                        'mask_png': self.mask_png(event,raw),
                        'mask_sha256': hashlib.sha256(raw).hexdigest(), 'ui_pixels': raw.count(255),
                        'basis': 'EGA bit provenance sampled at original scanline time'}
        elif event == 31:
            if slot_or_page not in range(3) or (raw and len(raw) != 64000*3):
                raise ValueError('invalid original driver mask frame')
            if raw and (self.ui_mask_slot != slot_or_page or len(self.scanout_ui_bits) != 64000):
                raise ValueError('driver mask lacks paired UI provenance')
            if not self.safe_driver_mask(raw, self.scanout_ui_bits):
                raise ValueError('unsafe original driver provenance')
            if self.scanout:
                self.scanout['driver_overlay'] = None
                if raw and raw[2::3].count(255):
                    self.scanout['driver_overlay'] = {'width':320,'height':200,
                        'mask_png':self.mask_png(event,raw),
                        'mask_sha256':hashlib.sha256(raw).hexdigest(),
                        'source':'SIM.EXE:5ba1..5da3','source_sha256':SIM_SHA256,
                        'basis':'original turret-relative driver assembly writes; per-bit offset sampled with each scanline'}
        elif event == 24:
            if slot_or_page not in range(3): raise ValueError('unknown core framebuffer slot')
            if raw and len(raw) != 64000: raise ValueError('unsupported plate mask dimensions')
            if raw.translate(INVALID_PLATE).count(1): raise ValueError('invalid plate provenance mask')
            if raw and (self.ui_mask_slot != slot_or_page or len(self.scanout_ui_bits) != 64000):
                raise ValueError('plate mask lacks paired UI provenance')
            if self.outside_ui(raw, self.scanout_ui_bits):
                raise ValueError('plate mask covers original world pixels')
            self.plate_mask_slot = slot_or_page
            if self.scanout:
                self.scanout['plate_overlay'] = None
                if raw:
                    self.scanout['plate_overlay'] = {'width':320, 'height':200,
                        'mask_png':self.mask_png(event,raw),
                        'mask_sha256':hashlib.sha256(raw).hexdigest(),
                        'plates':{str(i+1):{'source':name,'pixels':raw.count(i+1),
                            'source_sha256':self.plates.resources[name][1]} for i,name in enumerate(PLATE_IDS)},
                        'basis':'all four EGA bits retain the same source plate and original coordinate at scanout'}
        elif event == 11:
            if slot_or_page not in range(3): raise ValueError('unknown core framebuffer slot')
            if self.ui_mask_slot is not None and self.ui_mask_slot != slot_or_page:
                raise ValueError('UI mask and completed framebuffer slots differ')
            if self.plate_mask_slot is not None and self.plate_mask_slot != slot_or_page:
                raise ValueError('plate mask and completed framebuffer slots differ')
            self.buffers[slot_or_page] = self.scanout
            self.scanout = None
            self.ui_mask_slot = None
            self.plate_mask_slot = None
            self.scanout_ui_bits = b''
        elif event == 12:
            if slot_or_page not in range(3): raise ValueError('unknown core framebuffer slot')
            frame = self.buffers.get(slot_or_page)
            width, height = registers[0], registers[1]
            if not 1 <= width <= 2048 or not 1 <= height <= 2048 or len(raw) != width * height * 4:
                raise ValueError('unsupported traced framebuffer dimensions')
            visible = self.text.present((frame or {}).get('_text_candidates', ()), raw, width, height,
                                        (frame or {}).get('palette_rgb'))
            orientation = self.orientation.present((frame or {}).get('_orientation_candidate'),raw,width,height,
                                                   (frame or {}).get('palette_rgb'))
            reticle = self.reticle.present((frame or {}).get('_reticle_candidate'),raw,width,height,
                                           (frame or {}).get('palette_rgb'))
            target_box = self.target_box.present((frame or {}).get('_target_box_candidate'),raw,width,height,
                                                 (frame or {}).get('palette_rgb'))
            dynamic_map = self.dynamic_map.present((frame or {}).get('_dynamic_map_candidate'),raw,width,height,
                                                   (frame or {}).get('palette_rgb'))
            metadata = {k:v for k,v in (frame or {}).items() if k not in ('_text_candidates','_orientation_candidate','_reticle_candidate','_target_box_candidate','_dynamic_map_candidate')}
            self.presented = {**(metadata or {'draw_pass': None, 'reason': 'unobserved framebuffer'}),
                'text_runs': visible, 'messages': visible_messages(visible), 'orientation': orientation,
                'reticle': reticle, 'target_box': target_box, 'dynamic_map': dynamic_map,
                'buffer_slot': slot_or_page, 'video_sha256': hashlib.sha256(raw).hexdigest(),
                'width': width, 'height': height}

    def paired_video(self, video):
        if self.error: raise self.error
        if not self.presented: return {'draw_pass': None, 'reason': 'waiting for observed framebuffer'}
        raw, width, height, pitch = video
        if (width, height, pitch) != (self.presented['width'], self.presented['height'], width * 4):
            raise ValueError('traced and libretro framebuffer dimensions differ')
        if hashlib.sha256(raw).hexdigest() != self.presented['video_sha256']:
            raise ValueError('traced and libretro framebuffer bytes differ')
        return self.presented

    def attach(self, core, load_segment):
        core.pause_at_frame_end()
        self.window_bundles = receipt_window_bundles(getattr(core, 'core_sha256', None), ROOT / '.runtime/pc-core')
        self.guided.enabled = receipt_capability(getattr(core, 'core_sha256', None), ROOT / '.runtime/pc-core')
        self.guided.reset()
        self.claim_strut = core.core.abrams_trace_claim_strut
        self.claim_strut.argtypes = [C.c_uint,C.c_uint,C.POINTER(C.c_uint8),C.c_uint]
        self.claim_strut.restype = C.c_bool
        self.claim_motor_pool = core.core.abrams_trace_claim_motor_pool
        self.claim_motor_pool.argtypes = [C.c_uint]
        self.claim_motor_pool.restype = C.c_bool
        core.core.abrams_trace_configure.argtypes = [C.c_uint16, CALLBACK]
        core.core.abrams_trace_configure.restype = None
        core.core.abrams_trace_configure(load_segment, self.callback)
        self.loop_diagnostic = None
        self.loop_sequence = 0
        if self.loop_diagnostics:
            configure = core.core.abrams_trace_loop_diagnostics
            configure.argtypes, configure.restype = [C.c_bool], None
            configure(True)

    def detach(self, core):
        self.guided.reset()
        core.pause_at_frame_end()
        # A zero load segment only disables instruction hooks. VGA callbacks
        # must also be removed before this Python callback can be released.
        core.core.abrams_trace_configure(0, CALLBACK())
        self.loop_diagnostic = None
        self.loop_sequence = 0
        self.active = None
        self.current = None
