# DOSBox Pure: Abrams corresponding source

Upstream: https://github.com/schellingb/dosbox-pure
Upstream commit: 73e03aa145e0549ed4d5a20f8e65532714da33f5
Corresponding compiled core SHA-256: 60f45558d61aaeaf5ab761fb1bd3fef95081d6eb0c4daffdee566b51af2af688

The source/ directory contains every tracked upstream file at this commit,
with the local source modifications recorded in CORE-BUILD.json and five
additional Abrams headers. All upstream licence and copyright notices remain
in their original files, including source/LICENSE, DOSBOX-AUTHORS and
DOSBOX-THANKS. DOSBox Pure and the Abrams modifications are GPL-2.0-or-later;
retain applicable component notices in source files when redistributing.

Local changes add instruction/render observation, VGA and plate ownership,
video presentation/raster callbacks, observer checkpoint/save-overlay
interfaces, and native save format 9, which stores the DOS calendar. The
complete modified files and added headers are included.
SOURCE-FILES.json records every included source file's SHA-256 and mode.
CORE-BUILD.json is the original compiled-core build receipt.

## Build on macOS ARM64

Install Apple's command-line developer tools (make and a C++ compiler), unpack this archive into a new directory, then run:

    cd source
    make -j4

This is the build command recorded in CORE-BUILD.json. The output is dosbox_pure_libretro.dylib. The recorded compiler was:
Apple clang version 21.0.0 (clang-2100.3.34.2)
The distributed binary is named abrams-trace.dylib. No patching step, game
installation, ROM, save data, baseline binary or network download is required
to compile this supplied patched source. See source/README.md and Makefile for
upstream build instructions and other target platforms. Recompilation was not
performed during archive creation; matching the recorded binary byte-for-byte
also depends on the original toolchain and build environment.

This archive contains emulator source and upstream resources only. It contains
no original Abrams game files or game ROM and confers no rights to those works.
