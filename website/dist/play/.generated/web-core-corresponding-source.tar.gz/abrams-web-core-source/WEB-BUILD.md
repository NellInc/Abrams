# Abrams Web core corresponding source

The `source/` tree is the pinned DOSBox Pure source, including every modified
upstream file and all five added observer headers. `web-prototype/` contains
the Web frontend, claim header and Emscripten build script. The original PC
game and Genesis ROM are not included or needed to compile this core.

Distributed core.wasm SHA-256: 0d7e1b9b89b60fc49a10ab17906b42fee7704f858e2a19605626d61ca1db882c
Pinned upstream commit: 73e03aa145e0549ed4d5a20f8e65532714da33f5

To rebuild, place `source/` at `.runtime/dosbox-pure-source/`, put
`SOURCE-FILES.json` at `.runtime/pc-core/SOURCE-FILES.json`, and place the files
in `web-prototype/` and `tools/package/` at the matching paths in this
project. Install Emscripten 6.0.10, activate its environment, then run
`python3 web-prototype/build_core.py --source-archive`. The published source
inventory is checked before compilation. No native core or original game
is needed. The emitted JavaScript and WebAssembly live under
`web-prototype/.generated/`.

This source is GPL-2.0-or-later. Preserve upstream and component notices.
See `source/LICENSE` and `LICENSES/GPL-2.0.txt` in the site package.
